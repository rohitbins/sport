// ignore_for_file: non_constant_identifier_names

import 'package:flutter/cupertino.dart';

TextEditingController numberController = TextEditingController();
int? SelectedIndex;
String? PhoneNumber;
String? KEY;
String? Month;
String? Year;
String? Messg;
String? LOGO;
String? NAME;

