import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Const {
  String player = 'Player\'s In';
}
 int IsChangedCount = 0;
bool? IsDataListNull = true;
int? SelectedIndex;
String? PhoneNumber;
String? KEY;
String? Month;
String? Year;
String? Messg;
String? LOGO;
String? NAME;
bool? TakePNPAttendance = false;
bool? TakeMemberAttendance = false;
bool? IsChanged = false;
bool? CanLogin = false;
bool ShowFee = false;
const String noRecordAvailable = 'No Record Available';

final DateFormat formatter = DateFormat('d\nMMM');
const String splash = 'assets/images/splash.jpeg';

const Color myBlue = Color(0xFF27ae60);
const Color myYellow = Color(0xFFf1c40f);
