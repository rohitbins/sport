// import 'package:flutter/material.dart';

// class  {
//   TextStyle Title = TextStyle(fontSize: 18, fontWeight: FontWeight.w600);
// }
