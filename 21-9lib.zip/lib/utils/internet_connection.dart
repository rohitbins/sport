// import 'dart:async';
// import 'package:internet_connection_checker/internet_connection_checker.dart';
//
//
// bool HasConnection = false;
//
// Future<void> internetConnection() async {
//   HasConnection = await InternetConnectionChecker().hasConnection;
// }