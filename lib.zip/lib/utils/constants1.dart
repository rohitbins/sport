import 'package:flutter/cupertino.dart';

TextEditingController numberController = TextEditingController();
int? SelectedIndex;
String? PhoneNumber;
String? KEY;
String? Month;
String? Year;
String? Messg;
String? LOGO;
String? NAME;
