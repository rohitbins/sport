abstract class CommonResponse {
  int? statusCode;

  bool? isError;

  String? message;
}
